<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Roles\\Providers\\RolesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Roles\\Providers\\RolesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);