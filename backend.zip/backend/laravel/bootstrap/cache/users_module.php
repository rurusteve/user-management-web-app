<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Users\\Providers\\UsersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Users\\Providers\\UsersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);