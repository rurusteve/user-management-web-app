<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Permissions\\Providers\\PermissionsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Permissions\\Providers\\PermissionsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);