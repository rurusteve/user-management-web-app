<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Traits\ApiResponser;

class ApiController extends Controller
{
    use ApiResponser;
}
